const http = require("http");
const https = require("https");
const app = require("./app");
const httpsOptions = require("./config/httpsOptions");

http.createServer(app).listen(3001, () => console.log("HTTP en 3001"));
https.createServer(httpsOptions, app).listen(3443, () => console.log("HTTPS en 3443"));
